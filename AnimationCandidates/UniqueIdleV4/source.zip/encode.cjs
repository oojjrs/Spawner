const fs = require('node:fs/promises');
const path = require('node:path');
const sharp = require('C:/Users/oojjr/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const work = 'H:/Spawner/$Trash/unique-idle-v4-20261027';
const output = 'H:/Spawner/AnimationCandidates/UniqueIdleV4';
(async () => {
  for (const key of ['spring-keeper', 'lantern-keeper']) {
    const folder = path.join(work, key);
    const destination = path.join(output, key);
    await fs.mkdir(destination, { recursive: true });
    const timeline = JSON.parse(await fs.readFile(path.join(folder, 'timeline.json'), 'utf8'));
    const delays = timeline.frames.map(frame => frame.durationMs);
    const frames = await Promise.all(timeline.frames.map(frame => sharp(path.join(folder, 'Frames', frame.drawing + '.png')).ensureAlpha().raw().toBuffer()));
    const raw = Buffer.concat(frames);
    const input = { animated: true, raw: { width: 512, height: frames.length * 512, channels: 4, pageHeight: 512 } };
    await sharp(raw, input).resize(256, 256).gif({ loop: 0, delay: delays, colours: 256, dither: 0, effort: 5 }).toFile(path.join(destination, 'idle.gif'));
    await sharp(raw, input).resize(64, 64).webp({ lossless: true, loop: 0, delay: delays }).toFile(path.join(destination, 'idle-64.webp'));
    await sharp({ create: { width: 4096, height: Math.ceil(frames.length / 8) * 512, channels: 4, background: '#00000000' } }).composite(timeline.frames.map((frame, index) => ({ input: path.join(folder, 'Frames', frame.drawing + '.png'), left: index % 8 * 512, top: Math.floor(index / 8) * 512 }))).webp({ lossless: true }).toFile(path.join(destination, 'idle-atlas.webp'));
    const metadata = { name: key, revision: 4, action: 'idle', frameSize: [512, 512], columns: 8, frameCount: frames.length, durationMs: timeline.durationMs, durationsMs: delays, loop: true, rootMotion: false, preview: 'idle.gif', thumbnail: 'idle-64.webp', atlas: 'idle-atlas.webp', sourceArchive: '../source.zip', method: key === 'spring-keeper' ? 'Original artwork with local weighted head rotation and an imagegen-drawn closed-eyelid attachment. Tail, body, wing and feet are stationary.' : 'Original artwork with local weighted ear rotation and timed lantern emission. Face, body, tail and feet are stationary.' };
    await fs.writeFile(path.join(destination, 'idle.json'), JSON.stringify(metadata, null, 2).replaceAll('\n', '\r\n') + '\r\n');
    console.log(JSON.stringify({ key, frames: frames.length, durationMs: timeline.durationMs, preview: path.join(destination, 'idle.gif') }));
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
