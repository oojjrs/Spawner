from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
import math
import json
import hashlib

repo = Path('H:/Spawner')
work = Path(__file__).resolve().parent
previous = repo / '$Trash/unique-idle-polish-20261027/authoring'
yy, xx = np.mgrid[:512, :512].astype(float)

def text(path, value):
    path.write_bytes((json.dumps(value) + '\n').replace('\n', '\r\n').encode('utf8'))

def smooth(value):
    a = np.clip(value, 0, 1)
    return a * a * (3 - 2 * a)

def polygon(points, blur):
    mask = Image.new('L', (512, 512), 0)
    ImageDraw.Draw(mask).polygon(points, 255)
    return np.array(mask.filter(ImageFilter.GaussianBlur(blur))).astype(float) / 255

def sample(array, x, y):
    x = np.clip(x, 0, 510.999999)
    y = np.clip(y, 0, 510.999999)
    ix, iy = x.astype(int), y.astype(int)
    u, v = (x - ix)[:, :, None], (y - iy)[:, :, None]
    return (array[iy, ix] * (1 - u) + array[iy, ix + 1] * u) * (1 - v) + (array[iy + 1, ix] * (1 - u) + array[iy + 1, ix + 1] * u) * v

def rotation(pivot, angle, weight):
    x, y = xx - pivot[0], yy - pivot[1]
    c, s = math.cos(angle), math.sin(angle)
    return np.stack(((c * x - s * y - x) * weight, (s * x + c * y - y) * weight), 2)

def warp(image, field):
    if not np.any(field):
        return image.copy()
    sx, sy = xx.copy(), yy.copy()
    for step in range(5):
        shift = sample(field, sx, sy)
        sx, sy = xx - shift[:, :, 0], yy - shift[:, :, 1]
    a = np.array(image).astype(float)
    a[:, :, :3] *= a[:, :, 3:4] / 255
    a = sample(a, sx, sy)
    a[:, :, :3] *= 255 / np.maximum(a[:, :, 3:4], .000001)
    a = np.clip(a, 0, 255).round().astype(np.uint8)
    a[a[:, :, 3] == 0] = 0
    return Image.fromarray(a)

def save_weight(path, weight):
    Image.fromarray(np.clip(weight * 255, 0, 255).astype(np.uint8)).save(path)

bird = work / 'spring-keeper'
rabbit = work / 'lantern-keeper'
for folder in [bird, rabbit]:
    (folder / 'Source').mkdir(511, True, True)
    (folder / 'Frames').mkdir(511, True, True)

original = Image.open(bird / 'Source/original.png' if (bird / 'Source/original.png').is_file() else previous / 'spring-keeper/Drawings/neutral.png').convert('RGBA')
original.save(bird / 'Source/original.png')
a = np.array(original).astype(float)
radius = ((xx - 161) / 17) ** 2 + ((yy - 237) / 17) ** 2
ring = (radius > 1.3) & (radius < 2.6) & (a[:, :, 0] > 190) & (a[:, :, 1] > 180)
x, y = (xx - 161) / 20, (yy - 237) / 20
features = np.stack((np.ones_like(x), x, y, x * x, x * y, y * y), 2)
surface = features @ np.linalg.lstsq(features[ring], a[ring, :3], None)[0]
cover = smooth((1.1 - np.sqrt(radius)) / .15)
closed = a.copy()
closed[:, :, :3] = a[:, :, :3] * (1 - cover[:, :, None]) + np.clip(surface, 0, 255) * cover[:, :, None]
generated = Image.open(work / 'bird-closed-generated.png').convert('RGBA').resize((512, 512), Image.Resampling.LANCZOS)
patch = np.array(generated.crop((144, 233, 183, 253))).astype(float)
patch[:, :, 3] *= np.clip((222 - patch[:, :, 0]) / 95, 0, 1)
patch[patch[:, :, 3] == 0] = 0
lid = Image.fromarray(np.clip(patch, 0, 255).astype(np.uint8)).resize((36, 18), Image.Resampling.LANCZOS)
layer = Image.new('RGBA', (512, 512), (0, 0, 0, 0))
layer.alpha_composite(lid, (143, 231))
layer.save(bird / 'Source/closed-eyelid.png')
closed_image = Image.alpha_composite(Image.fromarray(np.clip(closed, 0, 255).astype(np.uint8)), layer)
closed_image.save(bird / 'Source/closed-eye.png')
head = polygon([(87,282),(85,225),(115,187),(134,183),(132,125),(207,94),(235,104),(238,132),(258,122),(273,135),(267,160),(283,177),(284,216),(262,234),(239,249),(222,278),(202,306),(128,307)], 3)
head *= smooth((324 - yy) / 49)
save_weight(bird / 'Source/head-weight.png', head)
text(bird / 'rig.json', {'canvas': [512,512], 'root': [191,397], 'bones': [{'name':'head','pivot':[191,287],'weight':'Source/head-weight.png','children':['crest-1','crest-2','crest-3','crest-4']}], 'stationary':['feet','body','wing','tail'], 'attachments': {'eye-open':'Source/original.png','eye-closed':'Source/closed-eye.png'}, 'durationMs':6400, 'stepMs':50, 'motion':{'nodRadians':-.085,'downMs':[1400,2000],'holdMs':[2000,2250],'returnMs':[2250,3200],'blinksMs':[[1880,2070],[4550,4700]]}})

original_rabbit = Image.open(rabbit / 'Source/original.png' if (rabbit / 'Source/original.png').is_file() else previous / 'lantern-keeper/Drawings/neutral.png').convert('RGBA')
original_rabbit.save(rabbit / 'Source/original.png')
left = polygon([(68,177),(76,137),(112,117),(169,127),(213,159),(239,206),(234,228),(201,228),(153,224),(111,202),(79,214)], 3)
right = polygon([(238,209),(255,159),(295,117),(359,90),(409,85),(443,111),(448,169),(410,180),(393,210),(346,238),(287,254),(256,243)], 3)
left *= smooth((np.hypot(xx-232,yy-220)-18)/48)
right *= smooth((np.hypot(xx-260,yy-224)-20)/48)
save_weight(rabbit / 'Source/left-ear-weight.png', left)
save_weight(rabbit / 'Source/right-ear-weight.png', right)
text(rabbit / 'rig.json', {'canvas':[512,512],'root':[283,423], 'bones':[{'name':'ear-left','pivot':[232,220],'weight':'Source/left-ear-weight.png'},{'name':'ear-right','pivot':[260,224],'weight':'Source/right-ear-weight.png'}], 'stationary':['face','body','feet','tail'],'emitters':[[84,194],[431,155],[259,222]],'durationMs':6800,'stepMs':50,'motion':{'leftRadians':.055,'rightRadians':-.045,'riseMs':[1600,2450],'holdMs':[2450,2800],'returnMs':[2800,4100]}})

def lanterns(image, field, amount):
    if amount <= 0:
        return image
    a = np.array(image).astype(float) / 255
    alpha = a[:, :, 3:4]
    premul = a[:, :, :3] * alpha
    glow = np.zeros((512,512))
    light = np.zeros((512,512))
    for px, py in [(84,194),(431,155),(259,222)]:
        dx, dy = field[py,px]
        r = (xx-px-dx)**2+(yy-py-dy)**2
        glow += np.exp(-r/110) * amount * .18
        light += np.exp(-r/48) * amount * .28
    light = np.clip(light,0,.5)[:,:,None]
    premul = premul * (1-light) + np.array([1,.89,.54]) * alpha * light
    bloom = np.clip(glow,0,.3)[:,:,None]
    premul = premul * (1-bloom) + np.array([1,.71,.2]) * bloom
    alpha = alpha + bloom * (1-alpha)
    result = np.concatenate((premul / np.maximum(alpha,.000001),alpha),2)
    return Image.fromarray(np.clip(result*255,0,255).round().astype(np.uint8))

for key, folder, duration in [('spring-keeper',bird,6400),('lantern-keeper',rabbit,6800)]:
    timeline = []
    known = {}
    for time in range(0,duration,50):
        if key == 'spring-keeper':
            down = smooth((time-1400)/600) * (1-smooth((time-2250)/950))
            angle = -.085 * down
            source = closed_image if 1880 <= time < 2070 or 4550 <= time < 4700 else original
            image = warp(source, rotation([191,287],angle,head))
        else:
            lift = smooth((time-1600)/850) * (1-smooth((time-2800)/1300))
            field = rotation([232,220],.055*lift,left) + rotation([260,224],-.045*lift,right)
            image = lanterns(warp(original_rabbit,field),field,lift)
        raw = image.tobytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest not in known:
            name = str(len(known)).zfill(3)
            known[digest] = name
            image.save(folder / 'Frames' / (name+'.png'))
        name = known[digest]
        if timeline and timeline[-1]['drawing']==name:
            timeline[-1]['durationMs'] += 50
        else:
            timeline.append({'drawing':name,'durationMs':50})
    text(folder/'timeline.json',{'name':key,'frameSize':512,'columns':8,'durationMs':duration,'loop':True,'frames':timeline})
    print(key,len(known),'drawings',len(timeline),'timeline frames',flush=True)

panel = Image.new('RGB',(1280,560),'#26312f')
for row,(folder,times) in enumerate([(bird,[0,1650,1950,2500,3200]),(rabbit,[0,1950,2550,3300,4100])]):
    timeline=json.loads((folder/'timeline.json').read_bytes())['frames']
    for col,time in enumerate(times):
        elapsed=0
        for frame in timeline:
            elapsed+=frame['durationMs']
            if time<elapsed:
                image=Image.open(folder/'Frames'/(frame['drawing']+'.png')).convert('RGBA').resize((256,256),Image.Resampling.LANCZOS)
                panel.paste(image,(col*256,row*280),image)
                ImageDraw.Draw(panel).text((col*256+5,row*280+258),str(time)+'ms','#ffffff')
                break
panel.save(work/'poses.png')
