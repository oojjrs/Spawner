const fs = require('node:fs/promises');
const path = require('node:path');
const root = 'H:/Spawner/$Trash/unique-idle-polish-20261027/authoring';
const frame = (drawing, durationMs) => ({ drawing, durationMs });
(async () => {
  const snailPath = ['enter-1', 'enter-2', 'open-1', 'open-2', 'open-3', 'open-4'];
  const snail = [frame('neutral', 800), ...snailPath.map((drawing, index) => frame(drawing, [160, 150, 180, 180, 210, 700][index])), ...snailPath.slice(0, -1).reverse().map((drawing, index) => frame(drawing, [150, 130, 130, 140, 180][index])), frame('neutral', 2600)];
  const rabbitUp = ['recover-3', 'load-3', 'rise-2', 'rise-4', 'keys-1'];
  const rabbitDown = ['down-2', 'down-gap-1', 'down-gap-3', 'down-4', 'keys-3'];
  const rabbit = [frame('neutral', 750), ...rabbitUp.map((drawing, index) => frame(drawing, [140, 170, 200, 240, 300][index])), ...rabbitDown.map((drawing, index) => frame(drawing, [210, 190, 200, 230, 330][index])), frame('recover-2', 220), frame('down-gap-1', 190), frame('recover-3', 200), frame('neutral', 1800)];
  for (const [name, frames] of [['old-garden-snail', snail], ['lantern-keeper', rabbit]]) {
    await fs.writeFile(path.join(root, name, 'timeline.json'), JSON.stringify({ name, frames }, null, 2).replaceAll('\n', '\r\n') + '\r\n');
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
