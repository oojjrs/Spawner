from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
import json
import math
import shutil

repo = Path('H:/Spawner')
work = repo / '$Trash/unique-idle-polish-20261027'
definitions = repo / 'DesignAssets/Animations/UniqueIdleV2'
source = repo / '$Trash/unused-images-20261027/DesignAssets/Animations/UniqueIdleV2'
output = work / 'authoring'

def polygon(points):
    mask = Image.new('L', (512, 512), 0)
    ImageDraw.Draw(mask).polygon(points, 255)
    return mask

def take(image, mask):
    pixels = np.array(image)
    pixels[:, :, 3] = (pixels[:, :, 3].astype(float) * np.array(mask) / 255).round().astype(np.uint8)
    pixels[pixels[:, :, 3] == 0] = 0
    return Image.fromarray(pixels)

def beak(image):
    a = np.array(image).astype(float)
    yy, xx = np.mgrid[0:512, 0:512]
    mask = (xx > 65) & (xx < 145) & (yy > 190) & (yy < 265) & (a[:, :, 3] > 180)
    mask &= (a[:, :, 0] > a[:, :, 1] * 1.16) & (a[:, :, 1] > a[:, :, 2] * 1.55) & (a[:, :, 0] > 130)
    candidates = []
    for y, x in zip(*np.where(mask)):
        if not mask[y, x]:
            continue
        pending = [(int(x), int(y))]
        mask[y, x] = False
        points = []
        while pending:
            px, py = pending.pop()
            points.append((px, py))
            for nx, ny in [(px - 1, py), (px + 1, py), (px, py - 1), (px, py + 1)]:
                if 0 <= nx < 512 and 0 <= ny < 512 and mask[ny, nx]:
                    mask[ny, nx] = False
                    pending.append((nx, ny))
        if len(points) < 12:
            continue
        p = np.array(points)
        width = p[:, 0].max() - p[:, 0].min() + 1
        height = p[:, 1].max() - p[:, 1].min() + 1
        if width > height * 1.25:
            candidates.append((len(points), p.mean(0), float(width)))
    if not candidates:
        raise RuntimeError('Beak anchor not found')
    chosen = sorted([(v[0], index) for index, v in enumerate(candidates)])[-1][1]
    return candidates[chosen][1], candidates[chosen][2]

def place(image, scale, anchor, destination):
    shift = np.asarray(destination) - np.asarray(anchor) * scale
    return image.transform((512, 512), Image.Transform.AFFINE, (1 / scale, 0, -shift[0] / scale, 0, 1 / scale, -shift[1] / scale), Image.Resampling.BICUBIC)

head_mask = polygon([(0, 0), (261, 0), (261, 250), (231, 267), (216, 280), (201, 291), (181, 298), (0, 298)])
tail_mask = polygon([(263, 0), (512, 0), (512, 512), (324, 512), (324, 369), (313, 365), (319, 361), (316, 353), (307, 338), (296, 326), (308, 326), (311, 322), (303, 312), (287, 300), (291, 299), (290, 295), (273, 283), (278, 281), (275, 278), (264, 263)])
wing_mask = polygon([(210, 260), (246, 258), (264, 263), (275, 278), (278, 281), (273, 283), (290, 295), (291, 299), (287, 300), (303, 312), (311, 322), (308, 326), (296, 326), (307, 338), (316, 353), (319, 361), (313, 365), (292, 366), (251, 367), (214, 340), (195, 309), (195, 286)])
neutral = Image.open(source / 'spring-keeper/Drawings/neutral.png').convert('RGBA')
target_beak, target_width = beak(neutral)
hip = np.array([279, 296])
yy, xx = np.mgrid[0:512, 0:512]
radius = np.sqrt((xx - hip[0]) ** 2 + (yy - hip[1]) ** 2)
target_tail = np.array(take(neutral, tail_mask))
target_radius = float(np.percentile(radius[(target_tail[:, :, 3] > 128) & (radius > 80)], 99.5))
body_mask = Image.fromarray(255 - np.maximum(np.array(head_mask), np.array(tail_mask)))
body = take(neutral, body_mask)
wing = take(neutral, wing_mask)

def smooth(value):
    value = np.clip(value, 0, 1)
    return value * value * (3 - 2 * value)

def sample(array, x, y):
    x = np.clip(x, 0, 510.99999)
    y = np.clip(y, 0, 510.99999)
    ix, iy = x.astype(int), y.astype(int)
    u, v = (x - ix)[:, :, None], (y - iy)[:, :, None]
    return (array[iy, ix] * (1 - u) + array[iy, ix + 1] * u) * (1 - v) + (array[iy + 1, ix] * (1 - u) + array[iy + 1, ix + 1] * u) * v

def normalize_parts(image, point, head_scale, tail_scale):
    yy, xx = np.mgrid[0:512, 0:512].astype(float)
    h = smooth((282 - xx) / 28) * smooth((331 - yy) / 51)
    t = np.array(tail_mask.filter(ImageFilter.GaussianBlur(5))).astype(float) / 255
    t *= smooth((radius - 30) / 55)
    dxh = target_beak[0] + (xx - point[0]) * head_scale - xx
    dyh = target_beak[1] + (yy - point[1]) * head_scale - yy
    dxt = (hip[0] - xx) * (1 - tail_scale)
    dyt = (hip[1] - yy) * (1 - tail_scale)
    field = np.stack([dxh * h + dxt * t, dyh * h + dyt * t], 2)
    sx, sy = xx.copy(), yy.copy()
    for iteration in range(7):
        delta = sample(field, sx, sy)
        sx, sy = xx - delta[:, :, 0], yy - delta[:, :, 1]
    texture = np.array(image).astype(float)
    texture[:, :, :3] *= texture[:, :, 3:4] / 255
    sampled = sample(texture, sx, sy)
    sampled[:, :, :3] = np.divide(sampled[:, :, :3] * 255, np.maximum(sampled[:, :, 3:4], 0.000001))
    result = np.clip(sampled, 0, 255).round().astype(np.uint8)
    result[np.array(image)[:, :, 3] == 0] = np.where(result[np.array(image)[:, :, 3] == 0, 3:4] > 0, result[np.array(image)[:, :, 3] == 0], 0)
    return Image.fromarray(result)
records = []
for key in ['spring-keeper', 'lantern-keeper', 'old-garden-snail']:
    folder = output / key / 'Drawings'
    folder.mkdir(511, True, True)
    (output / key / 'Source').mkdir(511, True, True)
    old_timeline = json.loads((definitions / key / 'timeline.json').read_bytes())
    for name in dict.fromkeys(frame['drawing'] for frame in old_timeline['frames']):
        image = Image.open(source / key / 'Drawings' / (name + '.png')).convert('RGBA')
        if key == 'spring-keeper' and name not in ['neutral', 'breath-1', 'breath-2', 'breath-3']:
            point, width = beak(image)
            head_scale = 0.97
            part = take(image, tail_mask)
            pixels = np.array(part)
            current_radius = float(np.percentile(radius[(pixels[:, :, 3] > 128) & (radius > 80)], 99.5))
            tail_scale = min(1, target_radius / current_radius)
            result = normalize_parts(image, point, head_scale, tail_scale)
            result.save(folder / (name + '.png'))
            records.append({'drawing': name, 'beakBefore': point.tolist(), 'beakTarget': target_beak.tolist(), 'headScaleCorrection': head_scale, 'tailRadiusBefore': current_radius, 'tailRadiusTarget': target_radius, 'tailScaleCorrection': tail_scale})
        else:
            image.save(folder / (name + '.png'))
    (output / key / 'Source/reference.txt').write_bytes(('DesignAssets/Animations/UniqueIdleV2/' + key + '/Drawings\r\n').encode('utf-8'))
    shutil.copy2(definitions / key / 'timeline.json', output / key / 'timeline.json')
(output / 'spring-keeper/Source/size-corrections.json').write_bytes((json.dumps(records) + '\r\n').encode('utf-8'))
panel = Image.new('RGB', (1280, 840), '#26312f')
draw = ImageDraw.Draw(panel)
names = list(dict.fromkeys(frame['drawing'] for frame in json.loads((definitions / 'spring-keeper/timeline.json').read_bytes())['frames']))
for index, name in enumerate(names):
    image = Image.open(output / 'spring-keeper/Drawings' / (name + '.png')).convert('RGBA').resize((256, 256), Image.Resampling.LANCZOS)
    left, top = index % 5 * 256, index // 5 * 280
    panel.paste(image, (left, top), image)
    draw.text((left + 5, top + 258), name, '#ffffff')
panel.save(work / 'bird-size-corrected.png')
print(json.dumps(records))
